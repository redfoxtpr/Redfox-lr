# Repository structure

- `web/` — integrated Redfox V4 HTML application.
- `assets/` — reserved for logos, icons, and static assets.
- `docs/` — print and deployment documentation.
- `.github/workflows/` — GitHub Pages deployment.
- `.gitignore` — excludes secrets, build artifacts and local files.
- `.env.example` — safe placeholder for environment configuration.
