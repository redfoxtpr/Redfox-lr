# LR Printing

The integrated UI supports:

| Format | CSS print size |
|---|---|
| A4 | 210 × 297 mm |
| A5 | 148 × 210 mm |
| 4×6 thermal | 101.6 × 152.4 mm |
| 80mm thermal | 80 mm paper width |

The preview includes the LR header, shipment details, charges, transport
details, and POD/delivery section.

For actual thermal printers, use the printer's native Android/Windows SDK
or Android Print Framework rather than relying on browser printing.
