# Redfox V4 — LR App

Premium Redfox Speed Parcel Service LR application UI with integrated LR printing.

## Included

- Redfox V4 LR interface
- LR Search & Print
- Integrated LR Print Preview
- A4 print layout
- A5 print layout
- 4×6 inch thermal layout
- 80mm thermal layout
- QR/barcode display areas
- Consignor / Consignee
- Pickup / Delivery address
- Weight and pieces
- Freight and other charges
- Payment / COD / E-Way Bill
- Vehicle / Driver / Route
- POD / delivery section
- Duplicate / Reprint watermark
- Print, WhatsApp and reprint actions
- Browser Save as PDF through the system print dialog

## Project structure

```text
redfox-v4/
├── .github/
│   └── workflows/
│       └── pages.yml
├── assets/
├── docs/
├── web/
│   └── index.html
├── .gitignore
├── LICENSE
└── README.md
```

## Run locally

Open `web/index.html` in a modern browser.

For a local server:

```bash
python -m http.server 8080 -d web
```

Then open:

```text
http://localhost:8080
```

## GitHub Pages

This repository includes a GitHub Actions workflow for publishing the `web/` folder to GitHub Pages.

Repository → Settings → Pages → Source: **GitHub Actions**.

## Production notes

The supplied application is the integrated HTML/UI build. It is not a replacement for the production backend.

Before production deployment:

- Connect LR records to the Redfox backend/database.
- Replace sample data with authenticated API data.
- Generate real QR codes and Code-128 barcodes.
- Keep Supabase secrets and service-role keys out of the repository.
- Use environment/build-time configuration for API keys.
- Use native Android Print Framework or approved printer SDKs for Bluetooth/USB/Wi-Fi thermal printing.
- Validate printer margins and paper dimensions on the actual hardware.

## Security

Do not commit:

- Supabase service-role keys
- Private API keys
- Google Maps private credentials
- Passwords
- Signing keys / keystores
- `.env` files containing secrets
